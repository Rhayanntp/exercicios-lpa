<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class TarefaFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'nome' => 'required|min:10|max:80',
            'date_hora'=> 'required|date_format:Y-m-d H:i',
            'descricao' => 'required|max:255'
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(
            response()->json([
                'status' => false,
                'message' => 'Erro de Validação',
                'errors' => $validator->errors()
            ], 422));
    }

    public function messages(){
        
        return[
            'nome.required' => 'o campo nome é obrigatorio',
            'nome.min' => 'o campo tem menos de 10 caracteres',
            'nome.max' => 'o campo nome tem mais de 80 caracteres',
            'date_hora.date_format' => 'voce esta preenxendo o campo de forma errada Ano-Mes-Dia ou voce esta deixando o campo em branco',
            'descricao.required' => 'o campo descricao esta vazio',
            'descricao.max' => 'o campo passou de 255 caracteres' 
        ];
    }
}
