<?php

namespace App\Http\Requests;

use Illuminate\Auth\Events\Validated;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class LivroFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'titulo' =>'max:255|required',
            'autor' => 'max:255|required', 
            'ano_publicado' => 'required',
            'genero' => 'max:255', 
            'descricao' => 'max:255',
            'editora' => 'max:255|required', 
            'isbn' => 'max:255|required|unique:livros', 
            'selo_editorial' => 'max:255'
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(
            response()->json([
                'status' => false,
                'message' => 'Erro de Validação',
                'errors' => $validator->errors()
            ], 422));
    }

    public function messages(){
        
        return[
            'titulo.required' => 'o titulo é obrigatorio',
            'titulo.max' => 'o titulo tem mais de 255 caracteres',
            'autor.required' => 'o autor é obrigatorio',
            'autor.max' => 'o autor tem mais de 255 caracteres',
            'ano_publicado.required' => 'o ano é obrigatorio',
            'genero.max' => 'o genero tem mais de 255 caracteres',
            'descricao.max' => 'o descricao tem mais de 255 caracteres',
            'editota.required' => 'o campo editora é obrigatoria',
            'editora.max' => 'o campo editora tem mais de 255 caracteres',
            'isbn.required' => 'o isbn é obrigatorio',
            'isbn.max' => 'o isbn tem mais de 255 caracteres',
            'isbn.unique' => 'o isbn tem que ser unico',
            'selo_editorial.max' => 'o selo_editorial tem mais de 255 caracteres'     
        ];
    }
}
